The crosses should be on the heart, not big ones in middle of torso.

Need more info on kettle helmets there are more late 12th/13th